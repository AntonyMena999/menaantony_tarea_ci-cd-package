
# 🚀 CI/CD con Python + GitHub Actions  
### 📦 Construcción automática de Package + Pruebas + Artefactos  
Autor: **Antony Mena**

---

## ✨ Objetivo del Proyecto

Este proyecto demuestra un pipeline **completo** de CI/CD usando **GitHub Actions**, cumpliendo con:

- ✅ Ejecución de pruebas unitarias  
- ✅ Construcción de un **package Python**  
- ✅ Generación de artefactos `.whl` y `.tar.gz`  
- ✅ Pipeline automatizado  
- ✅ Documentación clara para la rúbrica  

---

## 📁 Estructura del Proyecto

```
tarea_ci_cd/
├── app.py
├── pyproject.toml
├── requirements.txt
├── tests/
│   └── test_app.py
└── .github/workflows/
    └── ci.yml
```

---

## ⚙️ ¿Cómo funciona el CI/CD?

### 1️⃣ **Commit & Push**
Cada vez que subes código a GitHub (`push` o PR a main/master):

### 2️⃣ **GitHub Actions inicia automáticamente**
- Descarga tu repositorio  
- Instala Python  
- Instala dependencias  
- Ejecuta pruebas  
- Construye el package  
- Sube los artefactos generados  

### 3️⃣ **Obtienes los artefactos**
En GitHub Actions aparecerá:

```
dist/
  tarea_ci_cd-0.1.0-py3-none-any.whl
  tarea_ci_cd-0.1.0.tar.gz
```

---

## 🧪 Ejecutar Pruebas Localmente

```bash
pytest
```

Debe aparecer:

```
1 passed
```

---

## 🧱 Construir Package Localmente

```bash
python -m build
```

Esto genera la carpeta:

```
dist/
```

---

## 📥 Instalar tu propio package (opcional)

```bash
pip install dist/*.whl
```

Luego pruébalo:

```python
from app import suma
print(suma(3, 4))
```

---

## 👤 Autor

**Antony Mena** – 2025  
